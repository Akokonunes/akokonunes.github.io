pivot.init({
    selector: "a",
    touch: false
});